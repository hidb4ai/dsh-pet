# 正确的导入方式
from .clients import AstraGRPCClient

__all__ = ['AstraGRPCClient']