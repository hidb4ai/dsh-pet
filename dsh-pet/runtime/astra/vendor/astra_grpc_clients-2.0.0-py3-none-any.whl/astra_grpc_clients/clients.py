#!/usr/bin/env python3

import grpc
import time
import json
import cv2
import numpy as np
import sys
import os
from typing import List, Optional, Any, Generator, Union, Dict, Type

# 确保加载本地 proto_python 目录（而非旧版本）
_self_dir = os.path.dirname(os.path.abspath(__file__))
_proto_dir = os.path.join(_self_dir, '..', 'proto_python')
if os.path.isdir(_proto_dir) and _proto_dir not in sys.path:
    sys.path.insert(0, os.path.join(_self_dir, '..'))

from proto_python import astra_service_pb2 as pb2
from proto_python import astra_service_pb2_grpc as pb2_grpc


class AstraGRPCClient:
    """
    完整 gRPC 客户端封装：
    - 在 __init__ 创建了 proto 中所有的 Stub。
    """

    def __init__(self, server_address: str = '192.168.8.12:50051'):
        self.server_address = server_address
        self.channel = grpc.insecure_channel(self.server_address)

        # 为 proto 中定义的所有 service 创建 stub
        self.gripper_stub = pb2_grpc.GripperServiceStub(self.channel)
        self.agv_stub = pb2_grpc.AgvServiceStub(self.channel)
        self.action_stub = pb2_grpc.ActionControlServiceStub(self.channel)
        self.planner_stub = pb2_grpc.PlannerControlServiceStub(self.channel)
        self.imgdetect_stub = pb2_grpc.ImgDetectServiceStub(self.channel)
        self.robot_state_stub = pb2_grpc.RobotStateServiceStub(self.channel)
        self.setmode_stub = pb2_grpc.SetModeServiceStub(self.channel)
        self.setservobreak_stub = pb2_grpc.SetServoBreakServiceStub(self.channel)
        self.sethome_stub = pb2_grpc.SetHomeOffsetServiceStub(self.channel)
        self.remote_stub = pb2_grpc.RemoteCommandStub(self.channel)
        self.cartesian_twist_stub = pb2_grpc.CartesianTwistServiceStub(self.channel)
        self.voice_stub = pb2_grpc.VoiceServiceStub(self.channel)
        self.image_stub = pb2_grpc.ImageServiceStub(self.channel)
        self.state_stub = pb2_grpc.StateServiceStub(self.channel)
        self.systemcommand_stub = pb2_grpc.SystemCommandServiceStub(self.channel)
        self.plannermanager_stub = pb2_grpc.PlannerManagerServiceStub(self.channel)
        self.demolog_stub = pb2_grpc.DemoLogServiceStub(self.channel)
        self.action_manager_stub = pb2_grpc.ActionManagerServiceStub(self.channel)
        self.hand_stub = pb2_grpc.HandServiceStub(self.channel)
        self.vr_stub = pb2_grpc.VRServiceStub(self.channel)
        
    def close(self):
        if self.channel:
            self.channel.close()

    # ---- 内部辅助 ----
    def _build_request(self, cls: Type[Any], data: Union[Any, Dict]) -> Any:
        """
        如果 data 已经是目标请求类型则直接返回，否则用 dict 填充新的请求对象。
        """
        if isinstance(data, cls):
            return data
        req = cls()
        if isinstance(data, dict):
            for k, v in data.items():
                try:
                    setattr(req, k, v)
                except Exception:
                    # 若字段为 repeated，需要使用 extend
                    try:
                        getattr(req, k).extend(v)
                    except Exception:
                        pass
        return req

    def _call_unary(self, method, req) -> Optional[Any]:
        try:
            return method(req)
        except grpc.RpcError as e:
            print(f"gRPC call failed: {e}")
            
    def _call_stream(self, method, req) -> Optional[Generator]:
        try:
            return method(req)
        except grpc.RpcError as e:
            print(f"gRPC stream call failed: {e}")
            
    # ---- Image service ----
    def get_camera_info(self, topic_name: str):
        req = pb2.CameraInfoRequest(topic_name=topic_name)
        response = self._call_unary(self.image_stub.GetCameraInfo, req)
        if response is None:
            print(f"获取相机信息失败: {topic_name}（服务端无响应或未找到相机信息）")
            return None
        return response.intrinsics, response.distortion, response.width, response.height, response.model

    def get_single_image_jpeg_base64(self, topic_name: str, quality: int = 0, fps_limit: int = 0, max_frames: int = 0):
        req = pb2.ImageRequest(topic_name=topic_name, quality=quality, fps_limit=fps_limit, max_frames=max_frames)
        response = self._call_unary(self.image_stub.GetSingleImage, req)
        if response is None:
            print(f"获取单张图像失败: {topic_name}（服务端无响应或未找到图像）")
            return None
        return response.stamp_sec, response.stamp_nsec, response.width, response.height, response.image_data, response.frame_id

    def get_single_color_depth_pair(self, color_topic, depth_topic, quality=80, sync_threshold_sec=0.05, depth_encoding=""):
        req = pb2.ColorDepthPairRequest(
            color_topic=color_topic,
            depth_topic=depth_topic,
            quality=quality,
            sync_threshold_sec=sync_threshold_sec,
            depth_encoding=depth_encoding,
        )
        response = self._call_unary(self.image_stub.GetSingleColorDepthPair, req)
        if response is None:
            return None
        color_bgr = self._decode_image_64jpeg2_bgr(response.color_image_data, response.color_width, response.color_height)
        if color_bgr is None:
            return None
        depth_img = self._decode_depth(response.depth_raw_data, response.depth_width, response.depth_height, response.depth_encoding)
        if depth_img is None:
            return None
        return response.stamp_sec, response.stamp_nsec, color_bgr, depth_img

    def get_color_depth_stream(self, color_topic, depth_topic, quality=80, sync_threshold_sec=0.05, depth_encoding="", fps_limit=0):
        req = pb2.ColorDepthPairRequest(
            color_topic=color_topic,
            depth_topic=depth_topic,
            quality=quality,
            sync_threshold_sec=sync_threshold_sec,
            depth_encoding=depth_encoding,
            fps_limit=fps_limit,
        )
        stream = self._call_stream(self.image_stub.GetColorDepthPairStream, req)
        if stream:
            for response in stream:
                color_size = len(response.color_image_data)
                depth_size = len(response.depth_raw_data)
                color_bgr = self._decode_image_64jpeg2_bgr(response.color_image_data, response.color_width, response.color_height)
                if color_bgr is None:
                    continue
                depth_img = self._decode_depth(response.depth_raw_data, response.depth_width, response.depth_height, response.depth_encoding)
                if depth_img is None:
                    continue
                yield response.stamp_sec, response.stamp_nsec, color_bgr, depth_img, color_size, depth_size

    # ---- Depth service ----
    # def _decode_depth(self, depth_data, width, height, encoding=""):
    #     if not encoding or encoding == "raw":
    #         arr = np.frombuffer(depth_data, dtype=np.uint16)
    #         if width > 0 and height > 0:
    #             return arr.reshape((height, width))
    #         side = int(np.sqrt(len(arr)))
    #         return arr.reshape((side, side))
    #     if encoding in ("compressed_rvl", "compressed", "compressed_png"):
    #         return None
    #     img_array = np.frombuffer(depth_data, dtype=np.uint8)
    #     img = cv2.imdecode(img_array, cv2.IMREAD_ANYDEPTH)
    #     if img is None:
    #         img = cv2.imdecode(img_array, cv2.IMREAD_UNCHANGED)
    #     if img is None:
    #         try:
    #             import PIL.Image
    #             from io import BytesIO
    #             img = np.array(PIL.Image.open(BytesIO(depth_data)))
    #         except Exception:
    #             return None
    #     if img is not None and img.dtype != np.uint16:
    #         img = img.astype(np.uint16)
    #     return img
    
    def _decode_depth(self, depth_data, width, height, encoding=""):
        if encoding == "raw":
            arr = np.frombuffer(depth_data, dtype=np.uint16)
            if width > 0 and height > 0:
                return arr.reshape((height, width))
            side = int(np.sqrt(len(arr)))
            return arr.reshape((side, side))
        if encoding == "png":
            # depth_data 是 PNG bytes，cv2 解码
            arr = np.frombuffer(depth_data, dtype=np.uint8)
            img = cv2.imdecode(arr, cv2.IMREAD_UNCHANGED)
            if img is None:
                try:
                    import PIL.Image
                    from io import BytesIO
                    img = np.array(PIL.Image.open(BytesIO(depth_data)))
                except Exception:
                    return None
            if img is not None:
                if img.dtype != np.uint16:
                    img = img.astype(np.uint16)
            return img
        return None

    @staticmethod
    def _colorize_depth(depth_img):
        """把深度图映射为 JET 伪彩色图 (uint16 -> BGR uint8)。"""
        if depth_img is None or depth_img.size == 0:
            return None
        dmax = float(depth_img.max())
        if dmax <= 0:
            viz = np.zeros(depth_img.shape, dtype=np.uint8)
        else:
            viz = (depth_img.astype(np.float32) / dmax * 255).astype(np.uint8)
        return cv2.applyColorMap(viz, cv2.COLORMAP_JET)

    @staticmethod
    def _make_color_depth_display(color_bgr, depth_img):
        """
        将彩色图与深度伪彩图水平拼接用于显示。

        彩色图与深度图分辨率常常不同(如 color 1920x1080, depth 640x480)，
        np.hstack 要求除拼接轴外的维度完全一致，因此拼接前先把深度图缩放到
        与彩色图相同高度，避免 "all the input array dimensions except for the
        concatenation axis must match exactly" 错误。
        """
        depth_colored = AstraGRPCClient._colorize_depth(depth_img)
        if depth_colored is None:
            return color_bgr.copy()
        if depth_colored.shape[0] != color_bgr.shape[0]:
            scale = color_bgr.shape[0] / float(depth_colored.shape[0])
            new_w = max(1, int(round(depth_colored.shape[1] * scale)))
            depth_colored = cv2.resize(
                depth_colored,
                (new_w, color_bgr.shape[0]),
                interpolation=cv2.INTER_NEAREST,
            )
        return np.hstack((color_bgr, depth_colored))

    def get_single_depth(self, topic_name: str, fps_limit: int = 0, max_frames: int = 0):
        req = pb2.DepthRequest(topic_name=topic_name, fps_limit=fps_limit, max_frames=max_frames)
        response = self._call_unary(self.image_stub.GetSingleDepth, req)
        if response is None:
            return None
        depth_img = self._decode_depth(response.depth_data, response.width, response.height, response.encoding)
        if depth_img is None:
            return None
        return response.stamp_sec, response.stamp_nsec, depth_img, response.frame_id, response.encoding

    def get_depth_stream(self, topic_name: str, fps_limit: int = 0, max_frames: int = 0):
        req = pb2.DepthRequest(topic_name=topic_name, fps_limit=fps_limit, max_frames=max_frames)
        stream = self._call_stream(self.image_stub.GetDepthStream, req)
        if stream:
            for response in stream:
                data_size = len(response.depth_data)
                depth_img = self._decode_depth(response.depth_data, response.width, response.height, response.encoding)
                if depth_img is None:
                    continue
                yield response.stamp_sec, response.stamp_nsec, depth_img, response.frame_id, data_size

    def get_image_stream_jpeg_base64(self, topic_name: str, quality: int = 0, fps_limit: int = 0, max_frames: int = 0):
        req = pb2.ImageRequest(topic_name=topic_name, quality=quality, fps_limit=fps_limit, max_frames=max_frames)
        stream_generator = self._call_stream(self.image_stub.GetImageStream, req)
        
        if stream_generator:
            for response in stream_generator:
                # 返回每个帧的数据
                yield (response.stamp_sec, response.stamp_nsec, response.width, 
                       response.height, response.image_data, response.frame_id)
                
    def _decode_image_642_bgr(self, image_data, width, height):
        """图像解码方法 - image_data 是原始 JPEG bytes，转为 BGR"""
        try:
            if not image_data:
                print("警告: 图像数据为空")
                return None
            image_array = np.frombuffer(image_data, dtype=np.uint8)
            image = cv2.imdecode(image_array, cv2.IMREAD_COLOR)
            if image is not None:
                return image
            # 回退到原始BGR格式
            if width <= 0 or height <= 0:
                return None
            expected_size = width * height * 3
            if len(image_array) != expected_size:
                return None
            return image_array.reshape((height, width, 3))
        except Exception as e:
            print(f"图像解码错误: {e}")
            return None

    def _decode_image_64jpeg2_bgr(self, image_data, width, height):
        """图像解码方法 - image_data 是原始 JPEG bytes，转为 BGR"""
        try:
            if not image_data:
                return None
            image_array = np.frombuffer(image_data, dtype=np.uint8)
            image = cv2.imdecode(image_array, cv2.IMREAD_COLOR)
            if image is not None:
                return image
            if width <= 0 or height <= 0:
                return None
            expected_size = width * height * 3
            if len(image_array) != expected_size:
                return None
            return image_array.reshape((height, width, 3))
        except Exception as e:
            print(f"图像解码错误: {e}")
            return None

    def _decode_image(self, image_data, width, height):
        """图像解码方法 - image_data 是原始 JPEG bytes，转为 BGR"""
        try:
            if not image_data:
                return None
            image_array = np.frombuffer(image_data, dtype=np.uint8)
            image = cv2.imdecode(image_array, cv2.IMREAD_COLOR)
            if image is not None:
                return image
            if width <= 0 or height <= 0:
                return None
            expected_size = width * height * 3
            if len(image_array) != expected_size:
                return None
            return image_array.reshape((height, width, 3))
        except Exception as e:
            print(f"图像解码错误: {e}")
            return None
        
    def get_single_image_bgr(self, topic_name: str, quality: int = 0, fps_limit: int = 0, max_frames: int = 0):
        """
        获取单张图像BGR格式
        Args:
            topic_name: 图像话题名称
            quality: 图像质量 (0-100)
        Returns:
            numpy.ndarray: BGR格式的图像数组
        """
        try:
            image_data = self.get_single_image_jpeg_base64(topic_name, quality, fps_limit, max_frames)
            if not image_data:
                print("获取单张图像失败")
                return None
            
            stamp_sec, stamp_nsec, width, height, image_bytes, frame_id = image_data
            print("width:", width, "height:", height)
            # 解码图像
            img = self._decode_image_64jpeg2_bgr(image_bytes, width, height)
            if img is None:
                print("图像解码失败")
                return None
            
            print(f"图像获取成功: {width}x{height}, 数据大小={len(image_bytes)}字节")
            print(f"时间戳: {stamp_sec}.{stamp_nsec:09d}, Frame ID: {frame_id}")

            return stamp_sec, stamp_nsec, width, height, img, frame_id
            
        except Exception as e:
            print(f"获取单张图像BGR失败: {e}")
            return None
        
    def get_image_stream_bgr(self, topic_name: str, quality: int = 0, fps_limit: int = 0, max_frames: int = 0):
        """
        获取图像流BGR格式
        Args:
            topic_name: 图像话题名称
            quality: 图像质量 (0-100)
            fps_limit: 帧率限制 (0=不限制)
        Returns:
            generator: 生成器，每次返回 (stamp_sec, stamp_nsec, width, height, img, frame_id)
        """
        req = pb2.ImageRequest(topic_name=topic_name, quality=quality, fps_limit=fps_limit, max_frames=max_frames)
        stream_generator = self._call_stream(self.image_stub.GetImageStream, req)
        try:
            if stream_generator:
                for response in stream_generator:
                    if not response:
                        print("获取图像流失败")
                        continue
                        
                    stamp_sec = response.stamp_sec
                    stamp_nsec = response.stamp_nsec
                    width = response.width
                    height = response.height
                    image_bytes = response.image_data
                    frame_id = response.frame_id
                    print("width:", width, "height:", height)
                    # 解码图像
                    img = self._decode_image_64jpeg2_bgr(image_bytes, width, height)
                    if img is None:
                        print("图像解码失败")
                        continue
                        
                    print(f"图像获取成功: {width}x{height}, 数据大小={len(image_bytes)}字节")
                    print(f"时间戳: {stamp_sec}.{stamp_nsec:09d}, Frame ID: {frame_id}")
                    
                    yield stamp_sec, stamp_nsec, width, height, img, frame_id
                
        except Exception as e:
            print(f"获取图像流BGR失败: {e}")
            return None
        
    def display_single_image_with_cv(self, topic_name: str, quality: int = 80, display_time: int = 3, fps_limit: int = 0, max_frames: int = 0):
        """
        使用OpenCV显示单张图像，显示指定时间后自动关闭
        Args:
            topic_name: 图像话题名称
            quality: 图像质量 (0-100)
            display_time: 显示时间(秒)
        """
        print(f"\n获取并显示单张图像: {topic_name}")
        print(f"图像将显示{display_time}秒后自动关闭")
        print("-" * 50)
        
        image_data = self.get_single_image_jpeg_base64(topic_name, quality, fps_limit, max_frames)
        if not image_data:
            print("获取单张图像失败")
            return
        
        stamp_sec, stamp_nsec, width, height, image_bytes, frame_id = image_data
        print("width:", width, "height:", height)
        img = self._decode_image(image_bytes, width, height)
        if img is None:
            print("图像解码失败")
            return
        
        print(f"图像获取成功: {width}x{height}, 数据大小={len(image_bytes)}字节")
        print(f"时间戳: {stamp_sec}.{stamp_nsec:09d}, Frame ID: {frame_id}")
        
        # 修复：创建图像的副本，避免只读问题
        display_img = img.copy()
        
        # 在图像副本上添加信息
        info_text = f"Single Image: {width}x{height}"
        cv2.putText(display_img, info_text, (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 
                   0.7, (0, 255, 0), 2)
        
        timestamp_text = f"Time: {stamp_sec}.{stamp_nsec:09d}"
        cv2.putText(display_img, timestamp_text, (10, 60), cv2.FONT_HERSHEY_SIMPLEX, 
                   0.7, (0, 255, 0), 2)
        
        frame_id_text = f"Frame ID: {frame_id}"
        cv2.putText(display_img, frame_id_text, (10, 90), cv2.FONT_HERSHEY_SIMPLEX, 
                   0.7, (0, 255, 0), 2)
        
        countdown_text = f"Closing in {display_time}s"
        cv2.putText(display_img, countdown_text, (10, 120), cv2.FONT_HERSHEY_SIMPLEX, 
                   0.7, (0, 255, 0), 2)
        
        window_name = f"Single Image: {topic_name}"
        
        try:
            # 显示图像副本
            cv2.imshow(window_name, display_img)
            print(f"图像已显示，将在{display_time}秒后自动关闭")
            print("按 'q' 键可立即关闭")
            
            # 设置定时关闭
            start_time = time.time()
            while True:
                current_time = time.time()
                elapsed = current_time - start_time
                remaining = display_time - elapsed
                
                # 更新倒计时显示
                if elapsed < display_time:
                    # 更新倒计时文本 - 每次都创建新的副本
                    temp_img = img.copy()
                    countdown_text = f"Closing in {max(0, int(remaining))}s"
                    cv2.putText(temp_img, countdown_text, (10, 120), cv2.FONT_HERSHEY_SIMPLEX, 
                               0.7, (0, 255, 0), 2)
                    cv2.imshow(window_name, temp_img)
                
                # 检查是否超时或用户按键
                if elapsed >= display_time:
                    print("显示时间到，自动关闭")
                    break
                    
                # 检查按键输入 (按'q'退出)
                if cv2.waitKey(100) & 0xFF == ord('q'):
                    print("用户手动关闭")
                    break
                    
        except Exception as e:
            print(f"显示图像时发生错误: {e}")
        finally:
            cv2.destroyAllWindows()
            print("图像窗口已关闭")

    def save_single_image(self, topic_name: str, quality: int = 80, filename: str = None, fps_limit: int = 0, max_frames: int = 0):
        """
        获取并保存单张图像到文件
        Args:
            topic_name: 图像话题名称
            quality: 图像质量
            filename: 保存文件名 (如果为None则自动生成)
        """
        print(f"\n获取并保存单张图像: {topic_name}")
        
        image_data = self.get_single_image_jpeg_base64(topic_name, quality, fps_limit, max_frames)
        if not image_data:
            print("获取单张图像失败")
            return
        
        stamp_sec, stamp_nsec, width, height, image_bytes, frame_id = image_data
        
        # 解码图像
        img = self._decode_image(image_bytes, width, height)
        if img is None:
            print("图像解码失败")
            return
        
        # 生成文件名
        if filename is None:
            filename = f"single_image_{stamp_sec}_{stamp_nsec:09d}.jpg"
        
        # 保存图像
        try:
            cv2.imwrite(filename, img)
            print(f"图像已保存: {filename}")
            print(f"图像信息: {width}x{height}, 时间戳: {stamp_sec}.{stamp_nsec:09d}")
        except Exception as e:
            print(f"保存图像失败: {e}")

    def display_image_stream_with_cv(self, topic_name: str, quality: int = 80, duration: int = 30, fps_limit: int = 0, max_frames: int = 0):
        """
        使用OpenCV显示流式图像
        Args:
            topic_name: 图像话题名称
            quality: 图像质量 (0-100)
            duration: 显示持续时间(秒)
            fps_limit: 帧率限制 (0=不限制)
        """
        print(f"\n开始OpenCV流式图像显示: {topic_name}")
        print("按 'q' 键退出显示")
        print("-" * 50)
        
        stream_generator = self.get_image_stream_jpeg_base64(topic_name, quality, fps_limit, max_frames)
        if not stream_generator:
            print("获取流式图像生成器失败")
            return
        
        frame_count = 0
        start_time = time.time()
        window_name = f"Stream: {topic_name}"
        
        try:
            for response in stream_generator:
                current_time = time.time()
                elapsed_time = current_time - start_time
                
                if elapsed_time >= duration:
                    break
                
                # 解包响应数据
                stamp_sec, stamp_nsec, width, height, image_data, frame_id = response
                frame_count += 1
                
                # 解码图像
                img = self._decode_image(image_data, width, height)
                if img is None:
                    print(f"第{frame_count}帧解码失败")
                    continue
                
                # 修复：创建图像的副本，避免只读问题
                display_img = img.copy()
                
                # 计算FPS
                fps = frame_count / elapsed_time if elapsed_time > 0 else 0
                
                # 在图像副本上添加信息
                info_text = f"Frame: {frame_count} FPS: {fps:.1f} Size: {img.shape[1]}x{img.shape[0]}"
                cv2.putText(display_img, info_text, (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 
                           0.7, (0, 255, 0), 2)
                
                timestamp_text = f"Time: {stamp_sec}.{stamp_nsec:09d}"
                cv2.putText(display_img, timestamp_text, (10, 60), cv2.FONT_HERSHEY_SIMPLEX, 
                           0.7, (0, 255, 0), 2)
                
                frame_id_text = f"Frame ID: {frame_id}"
                cv2.putText(display_img, frame_id_text, (10, 90), cv2.FONT_HERSHEY_SIMPLEX, 
                           0.7, (0, 255, 0), 2)
                
                # 显示图像副本
                cv2.imshow(window_name, display_img)
                
                # 每10帧打印一次统计信息
                if frame_count % 10 == 0:
                    print(f"已显示{frame_count}帧, 实时FPS={fps:.1f}")
                
                # 检查按键输入 (按'q'退出)
                if cv2.waitKey(1) & 0xFF == ord('q'):
                    print("用户手动退出")
                    break
                    
        except grpc.RpcError as e:
            print(f"gRPC流错误: {e}")
        except Exception as e:
            print(f"处理错误: {e}")
        finally:
            cv2.destroyAllWindows()
            total_time = time.time() - start_time
            avg_fps = frame_count / total_time if total_time > 0 else 0
            print(f"\n显示完成:")
            print(f"总帧数: {frame_count}")
            print(f"总时间: {total_time:.2f}秒")
            print(f"平均FPS: {avg_fps:.1f}")

    def save_image_stream_frames(self, topic_name: str, quality: int = 80, 
                               save_interval: int = 10, max_frames: int = 100, 
                               output_dir: str = "./saved_frames", fps_limit: int = 0, stream_max_frames: int = 0):
        """
        保存流式图像帧到文件
        Args:
            topic_name: 图像话题名称
            quality: 图像质量
            save_interval: 保存间隔 (每N帧保存一次)
            max_frames: 最大保存帧数
            output_dir: 输出目录
        """
        import os
        os.makedirs(output_dir, exist_ok=True)
        
        print(f"\n开始保存流式图像帧到: {output_dir}")
        print(f"保存间隔: 每{save_interval}帧保存一次")
        print("-" * 50)
        
        stream_generator = self.get_image_stream_jpeg_base64(topic_name, quality, fps_limit, stream_max_frames)
        if not stream_generator:
            print("获取流式图像生成器失败")
            return
        
        frame_count = 0
        saved_count = 0
        start_time = time.time()
        
        try:
            for response in stream_generator:
                if saved_count >= max_frames:
                    break
                    
                # 解包响应数据
                stamp_sec, stamp_nsec, width, height, image_data, frame_id = response
                frame_count += 1
                
                # 按间隔保存帧
                if frame_count % save_interval == 0:
                    img = self._decode_image(image_data, width, height)
                    if img is not None:
                        filename = f"frame_{saved_count:04d}_{stamp_sec}_{stamp_nsec:09d}.jpg"
                        filepath = os.path.join(output_dir, filename)
                        cv2.imwrite(filepath, img)
                        saved_count += 1
                        print(f"已保存第{saved_count}帧: {filename}")
                        
                # 显示进度
                if frame_count % 50 == 0:
                    elapsed_time = time.time() - start_time
                    fps = frame_count / elapsed_time if elapsed_time > 0 else 0
                    print(f"已处理{frame_count}帧, 已保存{saved_count}帧, FPS={fps:.1f}")
                    
        except grpc.RpcError as e:
            print(f"gRPC流错误: {e}")
        except Exception as e:
            print(f"处理错误: {e}")
        finally:
            total_time = time.time() - start_time
            print(f"\n保存完成:")
            print(f"总处理帧数: {frame_count}")
            print(f"已保存帧数: {saved_count}")
            print(f"总时间: {total_time:.2f}秒")

    # ---- Voice service ----
    def get_asr_info(self):
        req = pb2.ASRInfoRequest()
        response =  self._call_unary(self.voice_stub.GetASRInfo, req)
        return response.asr_text

    def get_voice_play_state(self):
        req = pb2.VoicePlayStateRequest()
        response = self._call_unary(self.voice_stub.GetVoicePlayState, req)
        
        import json
        # 如果response是包含JSON字符串的对象
        if hasattr(response, 'state'):
            # 如果state属性本身就是字符串
            data = json.loads(response.state)
            return data['state']
        else:
            # 如果整个response是JSON字符串
            data = json.loads(str(response))
            return data['state']

    def publish_tts_text(self, text: str):
        req = pb2.TTSTextRequest(tts_text=text)
        self._call_unary(self.voice_stub.PublishTTSText, req)

    def publish_demo_log(self, data: str):
        """发布运行日志"""
        req = pb2.DemoLogRequest(data=data)
        response = self._call_unary(self.demolog_stub.PublishDemoLog, req)
        if response:
            return response.success, response.message
        return False, "gRPC call failed"

    # ---- Remote command (点动/遥控) ----
    def body_joint_remote_command(self, joints: List[str],vel: List[float]):
        req = pb2.RemoteCommandRequest(joint_names = joints, velocities = vel)
        self._call_unary(self.remote_stub.BodyJointRemoteCommand, req)

    def left_joint_remote_command(self, joints: List[str],vel: List[float]):
        req = pb2.RemoteCommandRequest(joint_names = joints, velocities = vel)
        self._call_unary(self.remote_stub.LeftJointRemoteCommand, req)

    def right_joint_remote_command(self, joints: List[str],vel: List[float]):
        req = pb2.RemoteCommandRequest(joint_names = joints, velocities = vel)
        self._call_unary(self.remote_stub.RightJointRemoteCommand, req)

    # ---- Cartesian twist (笛卡尔点动) ----
    def left_cartesian_twist_command(self, linear_x=0.0, linear_y=0.0, linear_z=0.0,
                                      angular_x=0.0, angular_y=0.0, angular_z=0.0,
                                      frame_id="agv_base_link"):
        req = pb2.CartesianTwistRequest(
            linear_x=linear_x, linear_y=linear_y, linear_z=linear_z,
            angular_x=angular_x, angular_y=angular_y, angular_z=angular_z,
            frame_id=frame_id)
        self._call_unary(self.cartesian_twist_stub.LeftCartesianTwistCommand, req)

    def right_cartesian_twist_command(self, linear_x=0.0, linear_y=0.0, linear_z=0.0,
                                       angular_x=0.0, angular_y=0.0, angular_z=0.0,
                                       frame_id="agv_base_link"):
        req = pb2.CartesianTwistRequest(
            linear_x=linear_x, linear_y=linear_y, linear_z=linear_z,
            angular_x=angular_x, angular_y=angular_y, angular_z=angular_z,
            frame_id=frame_id)
        self._call_unary(self.cartesian_twist_stub.RightCartesianTwistCommand, req)

    # ---- Gripper service ----
    def left_gripper_control(self, is_open: bool, position: int, velocity: int, force: int):
        req = pb2.GripperControlRequest(is_open = is_open, position =  position,velocity =  velocity, force = force)
        response = self._call_unary(self.gripper_stub.LeftGripperControl, req)
       
            
        return response.success, response.result_code, response.result_description

    def right_gripper_control(self, is_open: bool, position: int, velocity: int, force: int):
        req = pb2.GripperControlRequest(is_open = is_open, position = position, velocity = velocity, force = force)
        response = self._call_unary(self.gripper_stub.RightGripperControl, req)
       
            
        return response.success, response.result_code, response.result_description

    def dual_gripper_control(self, is_open: bool, position: int, velocity: int, force: int):
        req = pb2.GripperControlRequest(is_open = is_open, position = position, velocity = velocity, force = force)
        response = self._call_unary(self.gripper_stub.DualGripperControl, req)
       
            
        return response.success, response.result_code, response.result_description

    def get_left_gripper_position(self):
        req = pb2.GripperPositionRequest()
        response = self._call_unary(self.gripper_stub.GetLeftGripperPosition, req)
        print(response)
       
            
        return response.position

    def get_right_gripper_position(self):
        req = pb2.GripperPositionRequest()
        response = self._call_unary(self.gripper_stub.GetRightGripperPosition, req)
        return response.position
    
    def get_left_gripper_state_code(self):
        req = pb2.StateCodeRequest()
        response = self._call_unary(self.gripper_stub.GetLeftGripperStateCode, req)
        return response.state_code

    def get_right_gripper_state_code(self):
        req = pb2.StateCodeRequest()
        response = self._call_unary(self.gripper_stub.GetRightGripperStateCode, req)
        return response.state_code

    def get_left_gripper_state_description(self):
        req = pb2.StateDescriptionRequest()
        response = self._call_unary(self.gripper_stub.GetLeftGripperStateDescription, req)  
        return response.description

    def get_right_gripper_state_description(self):
        req = pb2.StateDescriptionRequest()
        response = self._call_unary(self.gripper_stub.GetRightGripperStateDescription, req) 
        return response.description

    # ---- AGV service ----
    def agv_move_by_site_blocking(self, site: int):
        req = pb2.AgvMoveBySiteBlockingRequest(site=site)
        response = self._call_unary(self.agv_stub.AgvMoveBySiteBlocking, req)
        return response.success, response.result_code, response.result_description

    def agv_nav_pause(self):
        req = pb2.TriggerRequest()
        response = self._call_unary(self.agv_stub.AgvNavPause, req)
        return response.success, response.message

    def agv_nav_continue(self):
        req = pb2.TriggerRequest()
        response = self._call_unary(self.agv_stub.AgvNavContinue, req)
        return response.success, response.message

    def agv_nav_cancel(self):
        req = pb2.TriggerRequest()
        response = self._call_unary(self.agv_stub.AgvNavCancel, req)
        return response.success, response.message

    def agv_set_control_mode(self, mode: int):
        req = pb2.AGVSetModeRequest(mode=mode)
        response = self._call_unary(self.agv_stub.AgvSetControlMode, req)
        return response.success

    def agv_emergency_stop(self):
        req = pb2.TriggerRequest()
        response = self._call_unary(self.agv_stub.AgvEmergencyStop, req)
        return response.success, response.message

    def agv_resume(self):
        req = pb2.TriggerRequest()
        response = self._call_unary(self.agv_stub.AgvResume, req)
        return response.success, response.message

    def get_agv_state_code(self):
        req = pb2.StateCodeRequest()
        response = self._call_unary(self.agv_stub.GetAgvStateCode, req)
        return response.state_code

    def get_agv_state_description(self):
        req = pb2.StateDescriptionRequest()
        response = self._call_unary(self.agv_stub.GetAgvStateDescription, req)
        return response.description

    def get_agv_connection_state_code(self):
        req = pb2.StateCodeRequest()
        response = self._call_unary(self.agv_stub.GetAgvConnectionStateCode, req)
        return response.state_code

    def get_agv_connection_state_description(self):
        req = pb2.StateDescriptionRequest()
        response = self._call_unary(self.agv_stub.GetAgvConnectionStateDescription, req)
        return response.description

    def get_agv_soc(self):
        req = pb2.StateCodeRequest()
        response = self._call_unary(self.agv_stub.GetAgvSoc, req)
        return response.state_code

    def agv_manual_control(self, linear_x: float, angular_z: float):
        req = pb2.AgvManualControlRequest(linear_x=linear_x, angular_z=angular_z)
        self._call_unary(self.agv_stub.AgvManualControl, req)
    
    # ---- Action control ----
    def action_control(self, action_id: int, command_id: str):
        req = pb2.ActionControlRequest(action_id=action_id, command_id=command_id)
        response = self._call_unary(self.action_stub.ActionControl, req)
        return response.success,response.action_id,response.command_id,response.result_code,response.result_description

    def action_control_edit(self, mode: int, id: int = -1, name: str = "", enable: bool = False,
                            max_vel: float = 0.0, max_acc: float = 0.0, move_group: str = "",
                            planning_type: str = "", target: List[float] = None, tmp: List[float] = None):
        req = pb2.ActionControlEditRequest()
        req.mode = mode
        req.id = id
        req.name = name
        req.enable = enable
        req.max_vel = max_vel
        req.max_acc = max_acc
        req.move_group = move_group
        req.planning_type = planning_type
        if target is not None:
            req.target.extend(target)
        if tmp is not None:
            req.tmp.extend(tmp)
        response = self._call_unary(self.action_stub.ActionControlEdit, req)
        return response.success,response.result_code,response.result_description

    def get_action_controller_state_code(self):
        req = pb2.StateCodeRequest()
        response = self._call_unary(self.action_stub.GetActionControllerStateCode, req)
        return response.state_code

    def get_action_controller_state_description(self):
        req = pb2.StateDescriptionRequest()
        response = self._call_unary(self.action_stub.GetActionControllerStateDescription, req)
        return response.description
    
    # ---- Planner control ----
    def planner_control(self,
                        max_vel_ratio: float = 0.0,
                        max_acc_ratio: float = 0.0,
                        move_group_name: str = "",
                        planning_type: str = "",
                        enable: bool = True,
                        target: List[float] = None,
                        tmp: List[float] = None):
        req = pb2.PlannerControlRequest()
        req.max_vel_ratio = max_vel_ratio
        req.max_acc_ratio = max_acc_ratio
        req.move_group_name = move_group_name
        req.planning_type = planning_type
        req.enable = enable
        if target:
            req.target.extend(target)
        if tmp:
            req.tmp.extend(tmp)
        response = self._call_unary(self.planner_stub.PlannerControl, req)
       
            
        return response.success, response.result_code, response.result_description

    def planner_control_stop(self):
        req = pb2.TriggerRequest()
        response = self._call_unary(self.planner_stub.PlannerControlStop, req)
        return response.success, response.message

    def planner_control_reverse(self):
        req = pb2.TriggerRequest()
        response = self._call_unary(self.planner_stub.PlannerControlReverse, req)
        return response.success, response.message

    def get_planner_state_code(self):
        req = pb2.StateCodeRequest()
        response = self._call_unary(self.planner_stub.GetPlannerControlServiceStateCode, req)
        return response.state_code

    def get_planner_state_description(self):
        req = pb2.StateDescriptionRequest()
        response = self._call_unary(self.planner_stub.GetPlannerControlServiceStateDescription, req)  
        return response.description

    # ---- ImgDetect ----
    def img_detect(self, obj: str, description: str, camera: str, radius: float = 0.03, only_judge: bool = False):
        req = pb2.ImgDetectRequest(obj=obj, description=description, camera=camera, radius=radius, only_judge=only_judge)
        response = self._call_unary(self.imgdetect_stub.ImgDetect, req)
        return response.success, response.has_flag, list(response.obj_pose), list(response.link7_pose)

    # ---- Robot state ----
    def get_body_joint_state(self):
        req = pb2.RobotStateRequest()
        response = self._call_unary(self.robot_state_stub.GetBodyJointValues, req)
        return list(response.state)

    def get_arms_joint_state(self):
        req = pb2.RobotStateRequest()
        response = self._call_unary(self.robot_state_stub.GetArmsJointValues, req)  
        return list(response.state)
    
    def get_arms_axis_state(self):
        req = pb2.RobotStateRequest()
        response = self._call_unary(self.robot_state_stub.GetArmsPoseValues, req)
        return list(response.state)

    # ---- SetMode ----
    def body_set_mode(self, mode: int):
        req = pb2.SetModeRequest(mode=mode)
        response = self._call_unary(self.setmode_stub.BodySetMode, req)
        return response.success

    def left_arm_set_mode(self, mode: int):
        req = pb2.SetModeRequest(mode=mode)
        response = self._call_unary(self.setmode_stub.LeftArmSetMode, req)
        return response.success

    def right_arm_set_mode(self, mode: int):
        req = pb2.SetModeRequest(mode=mode)
        response = self._call_unary(self.setmode_stub.RightArmSetMode, req)
        return response.success

    def robot_set_mode(self, mode: int):
        req = pb2.SetModeRequest(mode=mode)
        response = self._call_unary(self.setmode_stub.RobotSetMode, req)
        return response.success

    def robot_emergency_stop(self):
        req = pb2.SetModeRequest(mode=5)
        response = self._call_unary(self.setmode_stub.RobotSetMode, req)
        return response.success

    def robot_resume(self):
        req = pb2.SetModeRequest(mode=4)
        response_1 = self._call_unary(self.setmode_stub.RobotSetMode, req)
        req = pb2.SetModeRequest(mode=6)
        response_2 = self._call_unary(self.setmode_stub.RobotSetMode, req)
        req = pb2.SetModeRequest(mode=3)
        response_3 = self._call_unary(self.setmode_stub.RobotSetMode, req)
        
        return response_1.success or response_2.success or response_3.success
    
    # ---- SetServoBreak ----
    def body_servo_break(self, ids: List[int], states: List[bool]):
        req = pb2.SetServoBreakRequest()
        req.ids.extend(ids)
        req.states.extend(states)
        response = self._call_unary(self.setservobreak_stub.BodyServoBreak, req)        
        return response.success

    def left_servo_break(self, ids: List[int], states: List[bool]):
        req = pb2.SetServoBreakRequest()
        req.ids.extend(ids)
        req.states.extend(states)
        response = self._call_unary(self.setservobreak_stub.LeftServoBreak, req)
        return response.success

    def right_servo_break(self, ids: List[int], states: List[bool]):
        req = pb2.SetServoBreakRequest()
        req.ids.extend(ids)
        req.states.extend(states)
        response = self._call_unary(self.setservobreak_stub.RightServoBreak, req)
        return response.success

    # ---- SetHomeOffset ----
    def body_set_home_off(self, ids: List[int]):
        req = pb2.SetHomeOffsetRequest()
        req.ids.extend(ids)
        response = self._call_unary(self.sethome_stub.BodySetHomeOff, req)
        return response.success

    def left_set_home_off(self, ids: List[int]):
        req = pb2.SetHomeOffsetRequest()
        req.ids.extend(ids)
        response = self._call_unary(self.sethome_stub.LeftSetHomeOff, req)
        return response.success

    def right_set_home_off(self, ids: List[int]):
        req = pb2.SetHomeOffsetRequest()
        req.ids.extend(ids)
        response = self._call_unary(self.sethome_stub.RightSetHomeOff, req)
        return response.success

    # ---- StateService ----
    def get_body_mode(self):
        req = pb2.ArmModeRequest()
        response = self._call_unary(self.state_stub.GetBodyMode, req)  
        return response.stamp_sec, response.stamp_nsec, response.mode

    def get_left_arm_mode(self):
        req = pb2.ArmModeRequest()
        response = self._call_unary(self.state_stub.GetLeftArmMode, req) 
        return response.stamp_sec, response.stamp_nsec, response.mode

    def get_right_arm_mode(self):
        req = pb2.ArmModeRequest()
        response = self._call_unary(self.state_stub.GetRightArmMode, req)
        return response.stamp_sec, response.stamp_nsec, response.mode

    def get_body_motor_error(self):
        req = pb2.MotorErrorRequest()
        response = self._call_unary(self.state_stub.GetBodyMotorError, req)
        return  response.stamp_sec,  response.stamp_nsec,  list(response.data)

    def get_left_motor_error(self):
        req = pb2.MotorErrorRequest()
        response = self._call_unary(self.state_stub.GetLeftMotorError, req)
        return  response.stamp_sec,  response.stamp_nsec,  list(response.data)

    def get_right_motor_error(self):
        req = pb2.MotorErrorRequest()
        response = self._call_unary(self.state_stub.GetRightMotorError, req)
        return  response.stamp_sec,  response.stamp_nsec,  list(response.data)

    def get_body_motor_state(self):
        req = pb2.MotorStateRequest()
        response = self._call_unary(self.state_stub.GetBodyMotorState, req)
        return  response.stamp_sec,  response.stamp_nsec,  list(response.data), list(response.breakstate)

    def get_left_motor_state(self):
        req = pb2.MotorStateRequest()
        response = self._call_unary(self.state_stub.GetLeftMotorState, req)
        return  response.stamp_sec,  response.stamp_nsec,  list(response.data), list(response.breakstate)

    def get_right_motor_state(self):
        req = pb2.MotorStateRequest()
        response = self._call_unary(self.state_stub.GetRightMotorState, req)
        return  response.stamp_sec,  response.stamp_nsec,  list(response.data), list(response.breakstate)

    def get_robot_soc(self):
        req = pb2.StateCodeRequest()
        response = self._call_unary(self.state_stub.GetRobotSoc, req)
        return response.state_code

    def execute_system_command(self, command: str):
        req = pb2.SystemCommandRequest(command=command)
        response = self._call_unary(self.systemcommand_stub.ExecuteSystemCommand, req)
        return response.success, response.message, response.exit_code

    # ---- PlannerManager service ----
    def planner_manager(self,
                        time_stamp: str = "",
                        execute_enable: bool = True,
                        body: Dict = None,
                        left_arm: Dict = None,
                        right_arm: Dict = None):
        """
        调用PlannerManager服务
        Args:
            time_stamp: 时间戳
            execute_enable: 是否执行规划路径
            body: body规划目标 dict {planning_types:[...], targets:[[...], ...], max_vel_ratio, max_accel_ratio, time_to_reach}
            left_arm: 左臂规划目标 dict
            right_arm: 右臂规划目标 dict
        Returns:
            (success, result_code, result_description)
        """
        req = pb2.PlannerManagerRequest()
        req.time_stamp = time_stamp
        req.execute_enable = execute_enable

        def _fill_target(dst, src):
            if src is None:
                return
            dst.planning_types.extend(src.get('planning_types', []))
            for t in src.get('targets', []):
                mt = dst.targets.add()
                mt.data.extend(t)
            dst.max_vel_ratio = src.get('max_vel_ratio', 0.0)
            dst.max_accel_ratio = src.get('max_accel_ratio', 0.0)
            dst.time_to_reach = src.get('time_to_reach', 0.0)

        if body is not None:
            _fill_target(req.body, body)
        if left_arm is not None:
            _fill_target(req.left_arm, left_arm)
        if right_arm is not None:
            _fill_target(req.right_arm, right_arm)

        response = self._call_unary(self.plannermanager_stub.PlannerManager, req)
        return response.success, response.result_description, response.plan

    def get_planner_manager_state_code(self):
        req = pb2.StateCodeRequest()
        response = self._call_unary(self.plannermanager_stub.GetPlannerManagerStateCode, req)
        return response.state_code

    def get_planner_manager_state_description(self):
        req = pb2.StateCodeRequest()
        response = self._call_unary(self.plannermanager_stub.GetPlannerManagerStateDescription, req)
        return response.description

    # ---- ActionManager service ----
    def action_manager(self,
                       action_id: List[int] = None,
                       command_description: str = ""):
        """
        调用ActionManager服务（执行动作）
        Args:
            action_id: 动作ID列表
            command_description: 命令描述
        Returns:
            (success, command_description, result_description)
        """
        req = pb2.ActionManagerRequest()
        if action_id:
            req.action_id.extend(action_id)
        req.command_description = command_description

        response = self._call_unary(self.action_manager_stub.ActionManager, req)
        return response.success, response.command_description, response.result_description

    def get_action_manager_state_code(self):
        req = pb2.StateCodeRequest()
        response = self._call_unary(self.action_manager_stub.GetActionManagerStateCode, req)
        return response.state_code

    def get_action_manager_state_description(self):
        req = pb2.StateCodeRequest()
        response = self._call_unary(self.action_manager_stub.GetActionManagerStateDescription, req)
        return response.description

    # ---- Hand service (灵巧手) ----
    def left_hand_control(self, data: List[float]):
        """位置控制: 发布 /left_hand/control"""
        req = pb2.HandControlRequest()
        req.data.extend(data)
        response = self._call_unary(self.hand_stub.LeftHandControl, req)
        if response is None:
            return False, "gRPC call failed"
        return response.success, response.message

    def right_hand_control(self, data: List[float]):
        """位置控制: 发布 /right_hand/control"""
        req = pb2.HandControlRequest()
        req.data.extend(data)
        response = self._call_unary(self.hand_stub.RightHandControl, req)
        if response is None:
            return False, "gRPC call failed"
        return response.success, response.message

    def get_left_hand_joint_states(self):
        """获取 /left_hand/joint_states"""
        req = pb2.HandJointStatesRequest()
        response = self._call_unary(self.hand_stub.GetLeftHandJointStates, req)
        if response is None:
            return None
        return (response.stamp_sec, response.stamp_nsec, response.frame_id,
                list(response.name), list(response.position),
                list(response.velocity), list(response.effort))

    def get_right_hand_joint_states(self):
        """获取 /right_hand/joint_states"""
        req = pb2.HandJointStatesRequest()
        response = self._call_unary(self.hand_stub.GetRightHandJointStates, req)
        if response is None:
            return None
        return (response.stamp_sec, response.stamp_nsec, response.frame_id,
                list(response.name), list(response.position),
                list(response.velocity), list(response.effort))

    def get_left_hand_force(self):
        """获取 /left_hand/force (20个值: 法向×5, 切向×5, 切向方向×5, 接近感应×5)"""
        req = pb2.HandForceRequest()
        response = self._call_unary(self.hand_stub.GetLeftHandForce, req)
        if response is None:
            return None
        return list(response.data)

    def get_right_hand_force(self):
        """获取 /right_hand/force (20个值: 法向×5, 切向×5, 切向方向×5, 接近感应×5)"""
        req = pb2.HandForceRequest()
        response = self._call_unary(self.hand_stub.GetRightHandForce, req)
        if response is None:
            return None
        return list(response.data)

    def get_left_hand_matrix_touch(self):
        """获取 /left_hand/matrix_touch (JSON字符串)"""
        req = pb2.HandMatrixTouchRequest()
        response = self._call_unary(self.hand_stub.GetLeftHandMatrixTouch, req)
        if response is None:
            return None
        return response.data

    def get_right_hand_matrix_touch(self):
        """获取 /right_hand/matrix_touch (JSON字符串)"""
        req = pb2.HandMatrixTouchRequest()
        response = self._call_unary(self.hand_stub.GetRightHandMatrixTouch, req)
        if response is None:
            return None
        return response.data

    def get_left_hand_matrix_touch_mass(self):
        """获取 /left_hand/matrix_touch_mass (JSON字符串)"""
        req = pb2.HandMatrixTouchMassRequest()
        response = self._call_unary(self.hand_stub.GetLeftHandMatrixTouchMass, req)
        if response is None:
            return None
        return response.data

    def get_right_hand_matrix_touch_mass(self):
        """获取 /right_hand/matrix_touch_mass (JSON字符串)"""
        req = pb2.HandMatrixTouchMassRequest()
        response = self._call_unary(self.hand_stub.GetRightHandMatrixTouchMass, req)
        if response is None:
            return None
        return response.data

    def left_hand_speed_control(self, data: List[float]):
        """设置左手指各关节速度上限: 发布 /left_hand/speed_control"""
        req = pb2.HandSpeedControlRequest()
        req.data.extend(data)
        response = self._call_unary(self.hand_stub.LeftHandSpeedControl, req)
        if response is None:
            return False, "gRPC call failed"
        return response.success, response.message

    def right_hand_speed_control(self, data: List[float]):
        """设置右手各关节速度上限: 发布 /right_hand/speed_control"""
        req = pb2.HandSpeedControlRequest()
        req.data.extend(data)
        response = self._call_unary(self.hand_stub.RightHandSpeedControl, req)
        if response is None:
            return False, "gRPC call failed"
        return response.success, response.message

    def left_hand_torque_control(self, data: List[float]):
        """设置左手各关节最大力矩(力限): 发布 /left_hand/torque_control"""
        req = pb2.HandTorqueControlRequest()
        req.data.extend(data)
        response = self._call_unary(self.hand_stub.LeftHandTorqueControl, req)
        if response is None:
            return False, "gRPC call failed"
        return response.success, response.message

    def right_hand_torque_control(self, data: List[float]):
        """设置右手各关节最大力矩(力限): 发布 /right_hand/torque_control"""
        req = pb2.HandTorqueControlRequest()
        req.data.extend(data)
        response = self._call_unary(self.hand_stub.RightHandTorqueControl, req)
        if response is None:
            return False, "gRPC call failed"
        return response.success, response.message

    def get_left_hand_fault_codes(self):
        """获取 /left_hand/fault_codes (JSON字符串)"""
        req = pb2.HandFaultCodesRequest()
        response = self._call_unary(self.hand_stub.GetLeftHandFaultCodes, req)
        if response is None:
            return None
        return response.data

    def get_right_hand_fault_codes(self):
        """获取 /right_hand/fault_codes (JSON字符串)"""
        req = pb2.HandFaultCodesRequest()
        response = self._call_unary(self.hand_stub.GetRightHandFaultCodes, req)
        if response is None:
            return None
        return response.data

    # ---- VR Replay ----
    def replay_start(self, name: str):
        req = pb2.ReplayStartRequest(name=name)
        response = self._call_unary(self.vr_stub.ReplayStart, req)
        if response is None:
            return False, "gRPC call failed"
        return response.success, response.message

    def replay_stop(self):
        req = pb2.TriggerRequest()
        response = self._call_unary(self.vr_stub.ReplayStop, req)
        if response is None:
            return False, "gRPC call failed"
        return response.success, response.message

    def replay_status(self):
        req = pb2.ReplayStatusRequest()
        response = self._call_unary(self.vr_stub.GetReplayStatus, req)
        if response is None:
            return "none"
        return response.status


def main():
    client = AstraGRPCClient('192.168.8.12:50051')
    try:
        print("=" * 60)
        print("开始测试所有gRPC服务")
        
    # 1. 测试语音服务
        # print("\n1. 测试语音服务")
        # print("-" * 30)
        
        # # 测试语音识别
        # while True:
        #     try:
        #         asr = client.get_asr_info()
        #         voice_play_state = client.get_voice_play_state()
        #         print(f"语音识别结果: {asr}")
        #         print(f"语音播放状态: {voice_play_state}")
        #     except grpc.RpcError as e:
        #         print(f"语音识别 异常: {e}")
        #     time.sleep(1)
        # # 测试语音合成
        # print("语音合成 测试语音服务 ...")
        # tts = client.publish_tts_text("测试语音服务")
        
        
        
    # # 2. 测试图像获取服务
        # print("\n2. 测试图像服务")
        # print("-" * 30)
        
        # # # 测试相机信息
        # print("测试相机信息 GetCameraInfo ...")
        # cam = client.get_camera_info(topic_name = "/right_camera/color/camera_info")
        # print(f"CameraInfo: ={cam}")

        # 单张图像获取BGR —— 参考 head_camera 的用法，改用胸口相机 chest_camera
        # print("调用 GetSingleImage (chest_camera) ...")
        # image = client.get_single_image_bgr(topic_name="/chest_camera/color/image_raw", quality=100, fps_limit=10, max_frames=1)
        # if image is None:
        #     print("chest_camera 图像获取失败：未收到图像，请确认相机驱动已启动且该话题正在发布")
        # else:
        #     print(f"chest_camera图像获取成功: 宽度={image[2]} 高度={image[3]} frame_id={image[5]}")
        #     cv2.imshow("Get Single Image (chest_camera)", image[4])
        #     cv2.waitKey(2000)
        #     cv2.destroyAllWindows()

        # === 流测试辅助函数(含带宽和FPS监测) ===
        def _bench_image_stream(topic_name, quality, label, fps_limit=10, max_frames=100):
            print(f"\n调用 GetImageStream [{label}] fps_limit={fps_limit}, max_frames={max_frames} ...")
            total_bytes = 0; frame_count = 0; start_ts = time.time()
            stream = client.get_image_stream_jpeg_base64(topic_name, quality, fps_limit=fps_limit, max_frames=max_frames)
            for stamp_sec, stamp_nsec, width, height, image_data, frame_id in stream:
                elapsed = time.time() - start_ts
                data_size = len(image_data); total_bytes += data_size
                img = client._decode_image(image_data, width, height)
                if img is None: continue
                frame_count += 1
                fps = frame_count / elapsed if elapsed > 0 else 0; bw = total_bytes * 8 / 1000 / elapsed if elapsed > 0 else 0
                display = img.copy()
                cv2.putText(display, f"FPS:{fps:.1f} BW:{bw:.0f}kbps Frame:{frame_count}",
                            (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)
                cv2.imshow(f"Stream [{label}]", display)
                if cv2.waitKey(1) & 0xFF == ord('q'): break
            cv2.destroyAllWindows()
            t = time.time() - start_ts
            print(f"[{label}] {frame_count}帧, {t:.1f}s, FPS={frame_count/t:.1f}, BW={total_bytes*8/1000/t:.0f}kbps")

        def _bench_depth_stream(topic_name, label, fps_limit=10, max_frames=100):
            print(f"\n调用 GetDepthStream [{label}] fps_limit={fps_limit}, max_frames={max_frames} ...")
            total_bytes = 0; frame_count = 0; start_ts = time.time()
            stream = client.get_depth_stream(topic_name, fps_limit=fps_limit, max_frames=max_frames)
            for stamp_sec, stamp_nsec, depth_img, frame_id, data_size in stream:
                elapsed = time.time() - start_ts; frame_count += 1; total_bytes += data_size
                fps = frame_count / elapsed if elapsed > 0 else 0; bw = total_bytes * 8 / 1000 / elapsed if elapsed > 0 else 0
                display = client._colorize_depth(depth_img)
                if display is None: continue
                cv2.putText(display, f"FPS:{fps:.1f} BW:{bw:.0f}kbps Frame:{frame_count}",
                            (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)
                cv2.imshow(f"Depth [{label}]", display)
                if cv2.waitKey(1) & 0xFF == ord('q'): break
            cv2.destroyAllWindows()
            t = time.time() - start_ts
            print(f"[{label}] {frame_count}帧, {t:.1f}s, FPS={frame_count/t:.1f}, BW={total_bytes*8/1000/t:.0f}kbps")

        def _bench_color_depth_stream(color_topic, depth_topic, label, quality=80, fps_limit=10, max_frames=100, depth_encoding=""):
            print(f"\n调用 ColorDepthStream [{label}] fps_limit={fps_limit}, max_frames={max_frames} ...")
            total_cb = 0; total_db = 0; frame_count = 0; start_ts = time.time()
            stream = client.get_color_depth_stream(color_topic=color_topic, depth_topic=depth_topic, quality=quality,
                                                    sync_threshold_sec=0.05, depth_encoding=depth_encoding,
                                                    fps_limit=fps_limit)
            for stamp_sec, stamp_nsec, color_bgr, depth_img, color_size, depth_size in stream:
                elapsed = time.time() - start_ts; frame_count += 1
                total_cb += color_size; total_db += depth_size
                fps = frame_count / elapsed if elapsed > 0 else 0; bw = (total_cb+total_db)*8/1000/elapsed if elapsed > 0 else 0
                combined = client._make_color_depth_display(color_bgr, depth_img)
                cv2.putText(combined, f"FPS:{fps:.1f} BW:{bw:.0f}kbps Frame:{frame_count}",
                            (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)
                cv2.imshow(f"ColorDepth [{label}]", combined)
                if cv2.waitKey(1) & 0xFF == ord('q') or frame_count >= max_frames: break
            cv2.destroyAllWindows()
            t = time.time() - start_ts
            print(f"[{label}] {frame_count}帧, {t:.1f}s, FPS={frame_count/t:.1f}, BW={(total_cb+total_db)*8/1000/t:.0f}kbps")

        # # === 单帧彩色深度同步对测试 ===
        # print("\n获取单帧 Color+Depth 同步对 ...")
        # result = client.get_single_color_depth_pair(
        #     color_topic="/head_camera/color/image_raw",
        #     depth_topic="/head_camera/depth/image_raw",
        #     quality=80, sync_threshold_sec=0.05)
        # if result:
        #     stamp_sec, stamp_nsec, color_bgr, depth_img = result
        #     combined = client._make_color_depth_display(color_bgr, depth_img)
        #     cv2.putText(combined, f"{stamp_sec}.{stamp_nsec:09d}  {color_bgr.shape[1]}x{color_bgr.shape[0]}",
        #                 (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)
        #     cv2.imshow("Single Color+Depth", combined)
        #     cv2.waitKey(3000)
        #     cv2.destroyAllWindows()

        # # === 单帧彩色深度压缩同步对测试 ===
        # print("\n获取单帧 Color+Depth 压缩同步对 ...")
        # result = client.get_single_color_depth_pair(
        #     color_topic="/head_camera/color/image_raw/compressed",
        #     depth_topic="/head_camera/depth/image_raw/compressedDepth",
        #     quality=80, sync_threshold_sec=0.05)
        # if result:
        #     stamp_sec, stamp_nsec, color_bgr, depth_img = result
        #     depth_viz = (depth_img / depth_img.max() * 255).astype(np.uint8)
        #     depth_colored = cv2.applyColorMap(depth_viz, cv2.COLORMAP_JET)
        #     combined = np.hstack((color_bgr, depth_colored))
        #     cv2.putText(combined, f"{stamp_sec}.{stamp_nsec:09d}  {color_bgr.shape[1]}x{color_bgr.shape[0]}",
        #                 (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)
        #     cv2.imshow("Single Color+Depth", combined)
        #     cv2.waitKey(3000)
        #     cv2.destroyAllWindows()

        # # === 活跃的流测试 ===
        # _bench_image_stream("/right_camera/color/image_raw", 100, "Raw", fps_limit=10, max_frames=0)
        # _bench_image_stream("/right_camera/color/image_raw/compressed", 0, "Compressed", fps_limit=10, max_frames=100)
        # _bench_depth_stream("/right_camera/aligned_depth_to_color/image_raw", "Depth", fps_limit=10, max_frames=100)
        # _bench_depth_stream("/right_camera/aligned_depth_to_color/image_raw/compressedDepth", "CompDepth", fps_limit=10, max_frames=100)
        
        # _bench_color_depth_stream("/right_camera/color/image_raw", "/right_camera/aligned_depth_to_color/image_raw",
        #                           "Color+Depth(raw)", fps_limit=10, max_frames=100)
        # _bench_color_depth_stream("/right_camera/color/image_raw/compressed", "/right_camera/aligned_depth_to_color/image_raw/compressedDepth",
        #                           "CompColor+CompDepth", fps_limit=10, max_frames=100)

    # # 3. 测试状态 解抱闸 设置原点服务 急停与恢复
        # print("\n3. 测试状态服务")
        # print("-" * 30)
        
        # # 测试身体控制器状态
        # print("调用 BodyMode ...")
        # body_mode = client.get_body_mode()
        # print(f"BodyMode", body_mode)

        # # 测试左臂控制器状态
        # print("调用 LeftArmMode ...")
        # left_mode = client.get_left_arm_mode()
        # print(f"LeftArmMode", left_mode)
        
        # # 测试右臂控制器状态
        # print("调用 RightArmMode ...")
        # right_mode = client.get_right_arm_mode()
        # print(f"RightArmMode", right_mode)
        
        # # 测试身体电机状态
        # print("调用 BodyMotorState ...")
        # mstate = client.get_body_motor_state()
        # print(f"BodyMotorState", mstate)

        # # 测试左臂电机状态
        # print("调用 LeftMotorState ...")
        # left_state = client.get_left_motor_state()
        # print(f"LeftMotorState", left_state)
        
        # # 测试右臂电机状态
        # print("调用 RightMotorState ...")
        # right_state = client.get_right_motor_state()
        # print(f"RightMotorState", right_state)
        
        # 测试身体电机错误状态
        # print("调用 BodyMotorError ...")
        # body_error = client.get_body_motor_error()
        # print(f"BodyMotorError", body_error)
        
        # # 测试左臂电机错误状态
        # print("调用 LeftMotorError ...")
        # left_error = client.get_left_motor_error()
        # print(f"LeftMotorError", left_error)
        
        # # 测试右臂电机错误状态
        # print("调用 RightMotorError ...")
        # right_error = client.get_right_motor_error()
        # print(f"RightMotorError", right_error)
        
        # # 测试解抱闸服务        
        # print("调用 解抱闸服务 ...")
        # res = client.left_servo_break([5], [False])
        # print(f"解抱闸服务", res)
        # time.sleep(3)
        
        # print("调用 解抱闸服务 ...")
        # res = client.left_servo_break([5], [True])
        # print(f"解抱闸服务", res)
        
        # # 测试设置原点服务        
        # print("调用 设置原点 ...")
        # res = client.left_set_home_off([5])
        # print(f"设置原点", res)
        
        # 测试点动
        # print("调用 点动左臂5轴 ...")
        # while True:
        #     try:
        #         time.sleep(0.3)
        #         res = client.left_joint_remote_command(["left_joint5"], [2.0])  
        #         print(f"点动", res)
        #     except Exception as e:
        #         print(f"点动异常: {e}")
        

        # 测试笛卡尔点动
        # print("测试左臂笛卡尔点动 (沿X正方向移动 0.01m/s, 持续2秒) ...")
        # print("测试左臂笛卡尔点动 ...")
        # for i in range(10):
        #     client.left_cartesian_twist_command(linear_z=0.1, frame_id="agv_base_link")
        #     time.sleep(1)

        # print("测试右臂笛卡尔点动 ...")
        # client.right_cartesian_twist_command(linear_x=0.1, linear_z=0.05, frame_id="agv_base_link")

        # duration = 1.0
        # start_time = time.time()
        # while time.time() - start_time < duration:
        #     client.right_cartesian_twist_command(angular_z=0.1, frame_id="agv_base_link")
        #     time.sleep(interval)
        # client.right_cartesian_twist_command(angular_z=0.0, frame_id="agv_base_link")
        # print("右臂笛卡尔点动完成")
        
        # # 测试急停服务
        # print("调用 急停服务 ...")
        # estop_resp = client.robot_emergency_stop()
        # print(f"急停服务", estop_resp)
        
        # # 测试恢复服务
        # print("调用 恢复服务 ...")
        # res = client.robot_resume()
        # print(f"恢复服务", res)
        
        # # 测试身体切换为手动模式
        # print("调用 BodyMode ...")
        # body_mode = client.robot_set_mode(8)
        # print(f"BodyMode", body_mode)
        
        # # 测试身体切换为自动模式
        # print("调用 BodyMode ...")
        # body_mode = client.robot_set_mode(1)
        # print(f"BodyMode", body_mode)
        
        
        
    # # 4. 测试夹爪服务
        # print("\n4. 测试夹爪服务")
        # print("-" * 30)
        
        # ## 测试左夹爪控制
        # print("调用 LeftGripperControl ...")
        # left_resp = client.left_gripper_control(is_open=False, position=0, velocity=255, force=255)
        # print(f"左夹爪控制调用返回： {left_resp}")
     
        # # 测试右夹爪控制
        # print("调用 RightGripperControl ...")
        # right_resp = client.right_gripper_control(is_open=False, position=0, velocity=255, force=255)
        # print(f"右夹爪控制调用返回： {right_resp}")

        
        # # 测试双夹爪控制
        # print("调用 DualGripperControl ...")
        # dual_resp = client.dual_gripper_control(is_open=False, position=255, velocity=255, force=255)
        # print(f"双夹爪控制调用返回： {dual_resp}")


        # # 获取夹爪状态和位置
        # left_gripper_code = client.get_left_gripper_state_code()
        # print(f"左夹爪状态码: {left_gripper_code}")
    
        # left_gripper_code_desc = client.get_left_gripper_state_description()
        # print(f"左夹爪状态描述: {left_gripper_code_desc}")
        
        # left_pos = client.get_left_gripper_position()
        # print(f"左夹爪位置: {left_pos}")
        
        # right_gripper_code = client.get_right_gripper_state_code()
        # print(f"右夹爪状态码: {right_gripper_code}")
        
        # right_gripper_code_desc = client.get_right_gripper_state_description()
        # print(f"右夹爪状态描述: {right_gripper_code_desc}")
        
        # right_pos = client.get_right_gripper_position()
        # print(f"右夹爪位置: {right_pos}")
        
        
        
    # # 5. 测试agv服务与话题
        # print("\n5. 测试agv服务")
        # print("-" * 30)
        
        # 测试agv急停
        # print("调用 AgvEmergencyStop ...")
        # estop_resp = client.agv_emergency_stop()
        # print(f"agv急停调用返回： {estop_resp}")
        # time.sleep(3)
        # # 测试agv恢复
        # print("调用 AgvResume ...")
        # resume_resp = client.agv_resume()
        # print(f"agv恢复调用返回： {resume_resp}")
        
        # # 测试agv站点导航到指定点
        # print("调用 AgvMoveBySiteBlocking ...")
        # move_resp = client.agv_move_by_site_blocking(site=2)
        # print(f"agv导航到指定点调用返回： {move_resp}")
        
        # # agv暂停导航
        # print("调用 AgvPause ...")
        # pause_resp = client.agv_nav_pause()
        # print(f"agv暂停导航调用返回： {pause_resp}")
        
        # agv继续导航
        # print("调用 AgvResumeNav ...")
        # resume_resp = client.agv_nav_continue()
        # print(f"agv继续导航调用返回： {resume_resp}")
        
        # agv取消导航
        # print("调用 AgvCancelNav ...")
        # cancel_resp = client.agv_nav_cancel()
        # print(f"agv取消导航调用返回： {cancel_resp}")
        # time.sleep(3)

        # print("调用 AgvSetControlMode ...")
        # setmode_resp = client.agv_set_control_mode(mode=2)
        # print(f"agv模式切换为手动调用返回： {setmode_resp}")
        # time.sleep(3)

        # ## 测试agv模式切换
        # print("调用 AgvSetControlMode ...")
        # setmode_resp = client.agv_set_control_mode(mode=1)
        # print(f"agv模式切换为自动调用返回： {setmode_resp}")
        

        
        #测试agv状态、连接状态、电量
        # agv_state_code = client.get_agv_state_code()
        # print(f"agv状态码: {agv_state_code}")
        # agv_state_desc = client.get_agv_state_description()
        # print(f"agv状态描述: {agv_state_desc}")   
        # agv_conn_state_code = client.get_agv_connection_state_code()
        # print(f"agv连接状态码: {agv_conn_state_code}")
        # agv_conn_state_desc = client.get_agv_connection_state_description()
        # print(f"agv连接状态描述: {agv_conn_state_desc}")
        # agv_soc = client.get_agv_soc()
        # print(f"agv电量SOC: {agv_soc}%")

        # print("调用 AgvSetControlMode ...")
        # setmode_resp = client.agv_set_control_mode(mode=2)
        # print(f"agv模式切换为手动调用返回： {setmode_resp}")
        
        # 测试agv手动移动
        # print("调用 MoveAgv ...")
        # duration = 1
        # frequency = 50
        # interval = 1.0 / frequency
        # start_time = time.time()

        # while time.time() - start_time < duration:
        #     move_resp = client.agv_manual_control(linear_x=0.0, angular_z=0.1)
        #     time.sleep(interval)

        # # 发送停止指令
        # client.agv_manual_control(linear_x=0.0, angular_z=0.0)
          
        
        
    # # 6. 测试获取各末端关节值或坐标服务
        # print("\n6. 测试获取关节值服务")
        # print("-" * 30)
        # # 获取身体关节值
        # print("调用 BodyJointState ...")
        # body_joints = client.get_body_joint_state()
        # print(f"身体关节值: {body_joints}")
        # # 获取左右臂关节值
        # print("调用 ArmsJointState ...")
        # arms_joints = client.get_arms_joint_state()
        # print(f"左右臂关节值: {arms_joints}")
        # #获取左右末端坐标
        # print("调用 ArmsJointState ...")
        # arms_axis = client.get_arms_axis_state()
        # print(f"左右臂末端坐标: {arms_axis}")
        
          
          
    # # 7. 测试planner控制服务
        # print("\n7. 测试planner 身体控制服务")
        # print("-" * 30)
        # # 测试planner控制
        # print("调用 PlannerControl ...")
        # planner_resp = client.planner_control(
        #     move_group_name="left_arm",
        #     planning_type="JOINT",
        #     enable=True,
        #     target=[0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0])
        # print(f"planner控制调用返回： {planner_resp}")
        
        # print("新增调用 PlannerControlReverse ...")
        # planner_reverse_resp = client.planner_control_reverse()
        # print(f"planner reverse 控制调用返回： {planner_reverse_resp}")
        
        # print("新增调用 PlannerControlStop ...")
        # planner_stop_resp = client.planner_control_stop()
        # print(f"planner stop 控制调用返回： {planner_stop_resp}")
        
        # planner_resp = client.planner_control(
        #     move_group_name="left_arm",
        #     planning_type="JOINT",
        #     enable=True,
        #     target=[0.7945412964103905, 0.938673789511732, 1.7610308278945312, 1.403894280996146, 3.0755901223855466, -0.0001353512459899095, -1.879878416526521e-06])
        # print(f"planner控制调用返回： {planner_resp}")
        
        # 获取planner状态码
        # planner_state_code = client.get_planner_state_code()
        # print(f"planner状态码: {planner_state_code}")
        # # 获取planner状态描述
        # planner_state_desc = client.get_planner_state_description()
        # print(f"planner状态描述: {planner_state_desc}")
        
        
        
    # # 8. 测试动作控制服务
        # print("\n8. 测试动作控制服务")
        # print("-" * 30)
        # # 测试动作控制
        # print("调用 ActionControl ...")
        # action_resp = client.action_control(
        #     action_id=9527,
        #     command_id="test body ")
        # print(f"动作控制调用返回： {action_resp}")
        
       #  # 获取动作控制器状态码
         # action_state_code = client.get_action_controller_state_code()
         # print(f"动作控制器状态码: {action_state_code}")
         # # 获取动作控制器状态描述
         # action_state_desc = client.get_action_controller_state_description()
         # print(f"动作控制器状态描述: {action_state_desc}")

       #  # 测试动作编辑（新增/删除/修改/清空）
        # print("调用 ActionControlEdit 新增动作 ...")
        # edit_resp = client.action_control_edit(
        #     mode=1, id=77777, name="test_pose", enable=True,
        #     max_vel=0.5, max_acc=0.3, move_group="left_arm",
        #     planning_type="JOINT",
        #     target=[0.1234563, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
        #     tmp=[0.0])
        # print(f"动作编辑(新增)调用返回: {edit_resp}")

         # print("调用 ActionControlEdit 删除动作 ...")
         # edit_resp = client.action_control_edit(
         #     mode=2, id=0, name="", enable=False,
         #     max_vel=0.0, max_acc=0.0, move_group="",
         #     planning_type="", target=[], tmp=[])
         # print(f"动作编辑(删除)调用返回: {edit_resp}")

         # print("调用 ActionControlEdit 修改动作 ...")
         # edit_resp = client.action_control_edit(
         #     mode=3, id=0, name="modified_pose", enable=True,
         #     max_vel=0.8, max_acc=0.6, move_group="right_arm",
         #     planning_type="POSE",
         #     target=[0.3, 0.0, 0.5, 0.0, 0.0, 0.0, 0.0],
         #     tmp=[0.0])
         # print(f"动作编辑(修改)调用返回: {edit_resp}")

         # print("调用 ActionControlEdit 清空动作 ...")
         # edit_resp = client.action_control_edit(
         #     mode=4, id=-1, name="", enable=False,
         #     max_vel=0.0, max_acc=0.0, move_group="",
         #     planning_type="", target=[], tmp=[])
         # print(f"动作编辑(清空)调用返回: {edit_resp}")

         
         
     # # 9. 测试图像检测服务
        # print("\n9. 测试图像检测服务")
        # print("-" * 30)
        # img_detect_resp = client.img_detect(
        #     obj="head",
        #     description="",
        #     camera="left",
        #     radius=0.0,
        #     only_judge=False)
        # print(f"图像检测调用返回： {img_detect_resp}")
        
        
        
    # # 10. 重启系统程序服务
        # print("\n10. start restart stop arm_init测试重启系统程序服务")
        # print("-" * 30)
        # system_command_resp = client.execute_system_command(
        #     command="start")
        # print(f"系统程序调用返回： {system_command_resp}")

    # 11. 测试运行日志发布
        # print("\n11. 测试运行日志发布服务")
        # print("-" * 30)
        # success, msg = client.publish_demo_log("程序启动完成")
        # print(f"发布运行日志: success={success}, message={msg}")
        # time.sleep(2)
        
        # success, msg = client.publish_demo_log("进入初始化阶段")
        # print(f"发布运行日志: success={success}, message={msg}")
        # time.sleep(2)

        # success, msg = client.publish_demo_log("开始执行动作序列")
        # print(f"发布运行日志: success={success}, message={msg}")

    # 12. 测试PlannerManager规划管理器服务
        # print("\n12. 测试PlannerManager规划管理器服务")
        # print("-" * 30)
        # body_targets = [[0.47630024, 1.3590943, 0.9992585, 0.5238172],
        #                 [0.47659025, 1.3592741, 0.9995406, -0.5240755]]
        # left_targets = [[0.5627502645766999, -0.02441089558738377, 1.0076745354787177,
        #                   0.19550284346664928, 0.6866896829278822, -0.23763232408779164, 0.6586097449214475]]
        # right_targets = [[0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0], [-0.1, -0.1, 0.1, -0.21, 0.1, 0.1, 0.1]]

        # pm_resp = client.planner_manager(
        #     time_stamp="",
        #     execute_enable=True,
        #     body={"planning_types": ["JOINT", "JOINT"], "targets": body_targets, "max_vel_ratio": 0.01, "max_accel_ratio": 0.01, "time_to_reach": 10.0},
        #     left_arm={"planning_types": ["JOINT"], "targets": left_targets, "max_vel_ratio": 0.1, "max_accel_ratio": 0.1, "time_to_reach": 5.0},
        #     right_arm={"planning_types": ["JOINT", "JOINT"], "targets": right_targets, "max_vel_ratio": 0.01, "max_accel_ratio": 0.01, "time_to_reach": 10.0}
        #     )
        # # print(f"PlannerManager调用返回: {pm_resp}")
        # print(f"是否成功: {pm_resp[0]}")
        # print(f"状态描述: {pm_resp[1]}")
        # print(f"规划详情: {pm_resp[2]}")

        # pm_state_desc = client.get_planner_manager_state_description()
        # print(f"PlannerManager状态描述: {pm_state_desc}")

    # 13. 测试ActionManager动作管理器服务
        # print("\n13. 测试ActionManager动作管理器服务")
        # print("-" * 30)

    # 测试ActionManager执行动作
        # am_resp = client.action_manager(
        #     action_id=[0, 622, 3],
        #     command_description="test action manager"
        # )
        # print(f"ActionManager调用返回: {am_resp}")

    # 获取ActionManager状态
        # am_state_code = client.get_action_manager_state_code()
        # print(f"ActionManager状态码: {am_state_code}")
        # am_state_desc = client.get_action_manager_state_description()
        # print(f"ActionManager状态描述: {am_state_desc}")

    # 14. 测试灵巧手服务 (HandService)
        # print("\n14. 测试灵巧手服务")
        # print("-" * 30)

        # # --- 位置控制: 发布 /left_hand/control, /right_hand/control ---
        # print("调用 LeftHandControl ...")
        # success, msg = client.left_hand_control([255, 255, 255, 255, 255, 255])
        # print(f"左手位置控制返回: success={success}, message={msg}")

        # print("调用 RightHandControl ...")
        # success, msg = client.right_hand_control([255, 255, 255, 255, 255, 255])
        # print(f"右手位置控制返回: success={success}, message={msg}")

        # # --- 关节状态: 获取 /left_hand/joint_states, /right_hand/joint_states ---
        # print("调用 GetLeftHandJointStates ...")
        # left_js = client.get_left_hand_joint_states()
        # if left_js:
        #     stamp_sec, stamp_nsec, frame_id, names, positions, velocities, efforts = left_js
        #     print(f"左手关节状态: frame_id={frame_id}")
        #     print(f"  关节名: {names}")
        #     print(f"  位置: {positions}")
        #     print(f"  速度(原始0-255): {velocities}")
        #     print(f"  力矩(保留): {efforts}")

        # # print("调用 GetRightHandJointStates ...")
        # right_js = client.get_right_hand_joint_states()
        # if right_js:
        #     stamp_sec, stamp_nsec, frame_id, names, positions, velocities, efforts = right_js
        #     print(f"右手关节状态: frame_id={frame_id}")
        #     print(f"  关节名: {names}")
        #     print(f"  位置: {positions}")
        #     print(f"  速度(原始0-255): {velocities}")
        #     print(f"  力矩(保留): {efforts}")

        # # --- 力反馈矩阵: 获取 /left_hand/force, /right_hand/force ---
        # # 20个值: [法向×5, 切向×5, 切向方向×5, 接近感应×5]
        # print("调用 GetLeftHandForce ...")
        # left_force = client.get_left_hand_force()
        # print(f"左手力反馈(20): {left_force}")

        # print("调用 GetRightHandForce ...")
        # right_force = client.get_right_hand_force()
        # print(f"右手力反馈(20): {right_force}")

        # # --- 触觉矩阵: 获取 /left_hand/matrix_touch, /right_hand/matrix_touch ---
        # print("调用 GetLeftHandMatrixTouch ...")
        # left_touch = client.get_left_hand_matrix_touch()
        # print(f"左手触觉矩阵JSON: {left_touch}")

        # print("调用 GetRightHandMatrixTouch ...")
        # right_touch = client.get_right_hand_matrix_touch()
        # print(f"右手触觉矩阵JSON: {right_touch}")

        # # --- 每指质量: 获取 /left_hand/matrix_touch_mass, /right_hand/matrix_touch_mass ---
        # print("调用 GetLeftHandMatrixTouchMass ...")
        # left_mass = client.get_left_hand_matrix_touch_mass()
        # print(f"左手每指质量JSON: {left_mass}")

        # print("调用 GetRightHandMatrixTouchMass ...")
        # right_mass = client.get_right_hand_matrix_touch_mass()
        # print(f"右手每指质量JSON: {right_mass}")

        # # --- 设置运动速度: 发布 /left_hand/speed_control, /right_hand/speed_control ---
        # print("调用 LeftHandSpeedControl ...")
        # success, msg = client.left_hand_speed_control([200, 200, 200, 200, 200, 200])
        # print(f"左手速度设置返回: success={success}, message={msg}")

        # print("调用 RightHandSpeedControl ...")
        # success, msg = client.right_hand_speed_control([200, 200, 200, 200, 200, 200])
        # print(f"右手速度设置返回: success={success}, message={msg}")

        # # --- 设置运动力矩: 发布 /left_hand/torque_control, /right_hand/torque_control ---
        # print("调用 LeftHandTorqueControl ...")
        # success, msg = client.left_hand_torque_control([150, 150, 150, 150, 150, 150])
        # print(f"左手力矩设置返回: success={success}, message={msg}")

        # print("调用 RightHandTorqueControl ...")
        # success, msg = client.right_hand_torque_control([150, 150, 150, 150, 150, 150])
        # print(f"右手力矩设置返回: success={success}, message={msg}")

        # # --- 故障码: 获取 /left_hand/fault_codes, /right_hand/fault_codes ---
        # print("调用 GetLeftHandFaultCodes ...")
        # left_fault = client.get_left_hand_fault_codes()
        # print(f"左手故障码JSON: {left_fault}")

        # print("调用 GetRightHandFaultCodes ...")
        # right_fault = client.get_right_hand_fault_codes()
        # print(f"右手故障码JSON: {right_fault}")

    # 15. 测试回放服务 (VR Replay)
        print("\n15. 测试回放服务")
        print("-" * 30)
        # 开始回放(非阻塞)
        print("调用 ReplayStart ...")
        success, msg = client.replay_start(name="20261106_115240.json")
        print(f"开始回放返回: success={success}, message={msg}")
        # 轮询回放状态，直到回放结束
        while True:
            status_str = client.replay_status()
            if status_str == "none":
                time.sleep(0.5)
                continue
            try:
                status = json.loads(status_str)
                if not status.get("is_replaying", False):
                    print(f"回放结束: {status.get('state', 'unknown')}")
                    break
            except json.JSONDecodeError:
                pass
            time.sleep(0.5)
        # 停止回放
        print("调用 ReplayStop ...")
        success, msg = client.replay_stop()
        print(f"停止回放返回: success={success}, message={msg}")

    except Exception as e:
        print(f"测试过程中发生错误: {e}")
    finally:
        client.close()


if __name__ == '__main__':
    main()